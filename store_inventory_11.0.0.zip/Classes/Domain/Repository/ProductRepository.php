<?php

namespace T3docs\StoreInventory\Domain\Repository;

/**
 * Class ProductRepository
 *
 * @package T3docs\StoreInventory\Domain\Repository
 */
class ProductRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{

}
