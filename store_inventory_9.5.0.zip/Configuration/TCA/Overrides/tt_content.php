<?php

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
    'T3docs.StoreInventory',
    'Pi1',
    'The Store Inventory List',
    'EXT:store_inventory/Resources/Public/Icons/Extension.svg'
);
