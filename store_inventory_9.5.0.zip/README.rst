\|
`Contributing <https://github.com/CONTRIBUTING.md>`__  \|
`Help & Support <https://typo3.org/help>`__ \|
`Settings <Documentation/Settings.cfg>`__ \|

======================================
TYPO3 Example Extension store_location
======================================

This TYPO3 extension is for the Extbase documentation located at

`Extbase Fluid Book, First extension <https://docs.typo3.org/typo3cms/ExtbaseFluidBook/4-FirstExtension/Index.html>`__

**Installation:** Can be installed via composer:
``composer req t3docs/store-inventory``

:Code Repository: https://github.com/TYPO3-Documentation/store_inventory
:TYPO3 Extension Repository: https://extensions.typo3.org/extension/store_inventory/
:Extension Key:  store_inventory
