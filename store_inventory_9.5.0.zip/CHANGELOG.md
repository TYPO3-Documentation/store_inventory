# 9.5.0

## TASK

- [TASK] Fix Vendor Prefix 0cf629f
- [TASK] Fix composer.json ab2005a
- [TASK] Move README to rest 959b17d
- [TASK] Make Version 9.5 compatible 9191f3d
- [TASK] First upload 8f1c692

## MISC

- Update README.md 96a81e8
- Initial commit 8e6e75e

